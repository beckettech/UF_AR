# ROS-ArloRobot
Repository for ROS modules related to research with the Arlo Robot.

To use, clone this repo into your catkin_workspace /src directory.

Full Image with Ubuntu, ROS, and ZynqRobotController v2 for ZyboZ7-10: [here](https://drive.google.com/open?id=1mOl_owtJ_ihtQE4YOjzLdk63Deryq1vm)
