#!/bin/bash

echo "ON\r" > /dev/ttyUSB0
