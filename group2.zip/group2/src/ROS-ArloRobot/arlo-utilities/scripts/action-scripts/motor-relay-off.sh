#!/bin/bash

echo "OFF\r" > /dev/ttyUSB0
