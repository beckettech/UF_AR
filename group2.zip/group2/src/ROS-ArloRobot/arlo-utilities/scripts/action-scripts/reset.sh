#/bin/bash

sudo reboot now
